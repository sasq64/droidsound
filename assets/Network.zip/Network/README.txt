If you want to add your own server to the network list using the .lnk files. 

1. Create a file with the extension .lnk, and one with the extension .lnk~

2. Put the directory URL you want to browse in both files. ie. http://download.lioncash.uni.cc/archive/

3. IMPORTANT! You will get <IO Error> if you don't follow this step.

	-Change your line endings to UNIX line endings. If they are DOS\Windows, you will get the <IO Error>.
	
	-Optional (I think, but I did it anyways to make sure), change the encoding to ISO 8859-1.

4. Save your files.

5. Just put them in the Network directory on your device and restart droidsound.

6. ????

7. Profit.